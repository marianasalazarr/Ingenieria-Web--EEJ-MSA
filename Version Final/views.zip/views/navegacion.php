
<a href="propiedades/crear" class="boton boton-verde">Nueva Propiedad</a>
<a href="vendedores/crear" class="boton boton-amarillo">Nuevo Vendedor</a>
<nav class="navegacion">
    <a href="/index">Propiedades</a>
    <?php if($_SESSION['tipo'] === 'administrador'): ?>
        <a href="/vendedores">Vendedores</a>
    <?php endif; ?>
    <a href="/cerrar-sesion">Cerrar Sesión</a>
</nav>

