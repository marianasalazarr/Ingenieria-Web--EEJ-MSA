<?php include __DIR__ . '/../includes/header.php'; ?>
<main class="contenedor seccion contenido-centrado">
    <h1>Registro de Usuario</h1>

    <?php foreach($errores as $error): ?>
        <div class="alerta error">
            <?php echo $error; ?>
        </div>
    <?php endforeach; ?>

    <?php if (!empty($mensaje)): ?>
        <div class="alerta exito">
            <?php echo $mensaje; ?>
        </div>
    <?php endif; ?>

    <form method="POST" class="formulario" novalidate>
        <fieldset>
            <legend>Email y Password</legend>

            <label for="email">E-mail</label>
            <input type="email" name="email" placeholder="Tu Email" id="email" required>

            <label for="password">Password</label>
            <input type="password" name="password" placeholder="Tu Password" id="password" required>
        </fieldset>

        <label for="tipo">Tipo de usuario:</label>
            <select name="tipo" id="tipo">
                <option value="">-- Seleccione --</option>
                <option value="administrador">Administrador</option>
                <option value="vendedor">Vendedor</option>
                <option value="cliente">Cliente</option>
            </select>


        </fieldset>

        <input type="submit" value="Registrar Usario" class="boton boton-verde">
    </form>
</main>
