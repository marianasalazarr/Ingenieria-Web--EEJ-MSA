<?php

require_once __DIR__ . '/../vendor/autoload.php';
require_once __DIR__ . '/../includes/app.php';

use MVC\Router;
use Controllers\PropiedadController;
use Controllers\VendedorController;
use Controllers\PaginasController;
use Controllers\LoginController;
use Controllers\RegistroController;
use Controllers\AdminController;

$router = new Router();

$router->get('/admin', [AdminController::class, 'index']);
$router->post('/admin/eliminar-propiedad', [AdminController::class, 'eliminarPropiedad']);
$router->post('/admin/eliminar-vendedor', [AdminController::class, 'eliminarVendedor']);

$router->get('/propiedades/crear', [PropiedadController::class, 'crear']);
$router->post('/propiedades/crear', [PropiedadController::class, 'crear']);
$router->get('/propiedades/actualizar', [PropiedadController::class, 'actualizar']);
$router->post('/propiedades/actualizar', [PropiedadController::class, 'actualizar']);
$router->post('/propiedades/eliminar', [PropiedadController::class, 'eliminar']);

$router->get('/vendedores', [VendedorController::class, 'index']);
$router->get('/vendedores/crear', [VendedorController::class, 'crear']);
$router->post('/vendedores/crear', [VendedorController::class, 'crear']);
$router->get('/vendedores/actualizar', [VendedorController::class, 'actualizar']);
$router->post('/vendedores/actualizar', [VendedorController::class, 'actualizar']);
$router->post('/vendedores/eliminar', [VendedorController::class, 'eliminar']);

$router->get('/', [PaginasController::class, 'index']);
$router->get('/nosotros', [PaginasController::class, 'nosotros']);
$router->get('/propiedades', [PaginasController::class, 'propiedades']);
$router->get('/propiedad', [PaginasController::class, 'propiedad']);
$router->get('/blog', [PaginasController::class, 'blog']);
$router->get('/entrada', [PaginasController::class, 'entrada']);
$router->get('/contacto', [PaginasController::class, 'contacto']);
$router->post('/contacto', [PaginasController::class, 'contacto']);

$router->get('/login', [LoginController::class, 'login']);
$router->post('/login', [LoginController::class, 'login']);
$router->get('/logout', [LoginController::class, 'logout']);

$router->get('/registro', [RegistroController::class, 'registrar']);
$router->post('/registro', [RegistroController::class, 'registrar']);

$router->get('/administrador', [AdminController::class, 'index']);
$router->get('/vendedor', [VendedorController::class, 'index']);
$router->get('/cliente', [PaginasController::class, 'index']);

$router->get('/index', [PaginasController::class, 'index']);
$router->get('/vendedor', function() {
    header('Location: /propiedades');
    exit;
});
$router->comprobarRutas();
