<?php

namespace Model;

class Admin extends ActiveRecord {

    protected static $tabla = 'admins';
    protected static $columnasDB = ['id', 'usuario', 'password']; // Añadir más columnas según tu base de datos

    public $id;
    public $usuario;
    public $password;

    public function __construct($args = []) {
        $this->id = $args['id'] ?? null;
        $this->usuario = $args['usuario'] ?? '';
        $this->password = $args['password'] ?? '';
    }

    public function validar() {
        $errores = [];

        // Implementa lógica de validación según tus requisitos
        if(empty($this->usuario) || empty($this->password)) {
            $errores[] = "Usuario y Password son obligatorios";
        }
        // Puedes añadir más validaciones aquí

        return $errores;
    }

    public static function login($usuario, $password) {
        $admin = self::findUsuario($usuario);

        if ($admin) {
            // Verificar la contraseña
            if (password_verify($password, $admin->password)) {
                return true; // Login exitoso
            }
        }

        return false; // Login fallido
    }

    protected static function findUsuario($usuario) {
        $query = "SELECT * FROM " . self::$tabla . " WHERE usuario = ?";
        $stmt = self::$db->prepare($query);
        $stmt->bind_param('s', $usuario);
        $stmt->execute();
        $result = $stmt->get_result();
        $admin = $result->fetch_object(self::class);
        $stmt->close();

        return $admin;
    }
}


