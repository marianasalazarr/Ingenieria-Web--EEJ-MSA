<?php

namespace Model;

use mysqli;

abstract class ActiveRecord {

    protected static $db;
    protected static $columnasDB = [];
    protected static $tabla = '';

    abstract public function __construct($args = []);

    public static function setDB($conexion) {
        self::$db = $conexion;
    }

    public static function find($id) {
        $query = "SELECT * FROM " . static::$tabla . " WHERE id = ${id} LIMIT 1";
        $resultado = self::$db->query($query);

        if (!$resultado) {
            return false;
        }

        return $resultado->fetch_assoc();
    }

    public static function all() {
        $query = "SELECT * FROM " . static::$tabla;
        $resultado = self::$db->query($query);

        $array = [];
        while ($registro = $resultado->fetch_assoc()) {
            $array[] = static::crearObjeto($registro);
        }

        return $array;
    }

    protected static function crearObjeto($registro) {
        $objeto = new static;

        foreach ($registro as $key => $value) {
            if (property_exists($objeto, $key)) {
                $objeto->$key = $value;
            }
        }

        return $objeto;
    }

    public function guardar() {
        if (empty($this->id)) {
            return $this->crear();
        } else {
            return $this->actualizar();
        }
    }

    protected function limpiarDatos() {
        $atributos = $this->sanitizarAtributos();
        foreach ($atributos as $key => $value) {
            $atributos[$key] = self::$db->escape_string($value);
        }
        return $atributos;
    }

    public function sanitizarAtributos() {
        return [
            'email' => $this->email,
            'password' => $this->password,
            'tipo' => $this->tipo
        ];
    }
}
