<?php

namespace Model;

class Usuario extends ActiveRecord {
    protected static $tabla = 'usuarios';
    protected static $columnasDB = ['id', 'email', 'password', 'tipo'];

    public $id;
    public $email;
    public $password;
    public $tipo;

    public function __construct($args = []) {
        $this->id = $args['id'] ?? null;
        $this->email = $args['email'] ?? '';
        $this->password = $args['password'] ?? '';
        $this->tipo = $args['tipo'] ?? '';
    }

    public function validar() {
        $errores = [];

        if (empty($this->email)) {
            $errores[] = "El Email es obligatorio";
        } elseif (!filter_var($this->email, FILTER_VALIDATE_EMAIL)) {
            $errores[] = "El Email no es válido";
        }

        if (empty($this->password)) {
            $errores[] = "El Password es obligatorio";
        } elseif (!preg_match('/[A-Z]/', $this->password)) {
            $errores[] = "El Password debe contener al menos una letra mayúscula";
        } elseif (!preg_match('/\d/', $this->password)) {
            $errores[] = "El Password debe contener al menos un número";
        } elseif (!preg_match('/[^a-zA-Z\d]/', $this->password)) {
            $errores[] = "El Password debe contener al menos un carácter especial";
        }

        return $errores;
    }

    public function existeUsuario() {
        $query = "SELECT * FROM " . self::$tabla . " WHERE email = '" . self::$db->escape_string($this->email) . "' LIMIT 1";
        $resultado = self::$db->query($query);

        return $resultado->fetch_object();
    }

    public function comprobarPassword($usuario) {
        if (password_verify($this->password, $usuario->password)) {
            $this->id = $usuario->id;
            $this->tipo = $usuario->tipo;
            return true;
        } else {
            self::$errores[] = 'El Password es Incorrecto';
            return false;
        }
    }

    public function autenticar() {
        session_start();
    
        $_SESSION['id'] = $this->id;
        $_SESSION['email'] = $this->email;
        $_SESSION['tipo'] = $this->tipo;
        $_SESSION['login'] = true;

        switch($this->tipo) {
            case 'administrador':
                header('Location: /administrador');
                break;
            case 'vendedor':
                header('Location: /vendedor');
                break;
            case 'cliente':
                header('Location: /cliente');
                break;
            default:
                header('Location: /');
                break;
        }
        exit;
    }
}
