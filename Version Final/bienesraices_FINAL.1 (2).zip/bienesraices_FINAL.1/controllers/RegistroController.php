<?php

namespace Controllers;

use MVC\Router;
use Model\Usuario;

class RegistroController {
    public static function registrar(Router $router) {
        $usuario = new Usuario();
        $errores = [];

        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $usuario = new Usuario($_POST);
            $errores = $usuario->validar();

            if (empty($errores)) {
                $existeUsuario = Usuario::where('email', $usuario->email);
                if ($existeUsuario) {
                    $errores[] = 'El usuario ya está registrado';
                } else {
                    $usuario->password = password_hash($usuario->password, PASSWORD_BCRYPT);

                    $resultado = $usuario->guardar();

                    if ($resultado) {
                        session_start();
                        $_SESSION['registro_exitoso'] = 'Usuario registrado correctamente. Ahora puedes iniciar sesión.';
                        header('Location: /login');
                        exit;
                    } else {
                        $errores[] = 'Error al registrar el usuario';
                    }
                }
            }
        }

        $router->render('auth/registro', [
            'usuario' => $usuario,
            'errores' => $errores
        ]);
    }
}

