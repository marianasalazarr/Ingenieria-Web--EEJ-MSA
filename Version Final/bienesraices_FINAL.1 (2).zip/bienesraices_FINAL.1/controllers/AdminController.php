<?php

namespace Controllers;

use MVC\Router;
use Model\Propiedad;
use Model\Vendedor;

class AdminController {
    public static function index(Router $router) {
        session_start();

        if (!isset($_SESSION['login'])) {
            header('Location: /login');
            exit;
        }

        if (!isset($_SESSION['tipo'])) {
            echo "Error: Tipo de usuario no está configurado en la sesión.";
            exit;
        }
        
        $tipo = $_SESSION['tipo'];
        $propiedades = Propiedad::all();
        $vendedores = Vendedor::all();

        $router->render('propiedades/index', [
            'propiedades' => $propiedades,
            'vendedores' => $vendedores,
            'tipo' => $tipo,
            'resultado' => $_GET['resultado'] ?? null
        ]);
    }

    public static function eliminarPropiedad() {
        session_start();
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            if (!isset($_SESSION['tipo']) || $_SESSION['tipo'] !== 'administrador') {
                header('Location: /');
                exit;
            }

            $id = $_POST['id'];
            $propiedad = Propiedad::find($id);

            if ($propiedad) {
                $propiedad->eliminar();
                header('Location: /admin?resultado=3');
                exit;
            } else {
                echo "Error: Propiedad no encontrada.";
            }
        }
    }

    public static function eliminarVendedor() {
        session_start();
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            if (!isset($_SESSION['tipo']) || $_SESSION['tipo'] !== 'administrador') {
                header('Location: /');
                exit;
            }

            $id = $_POST['id'];
            $vendedor = Vendedor::find($id);

            if ($vendedor) {
                $vendedor->eliminar();
                header('Location: /admin?resultado=3');
                exit;
            } else {
                echo "Error: Vendedor no encontrado.";
            }
        }
    }
}
