<?php

namespace Controllers;

use MVC\Router;
use Model\Propiedad;
use Model\Vendedor;
use Intervention\Image\ImageManagerStatic as Image;

class PropiedadController {

    public static function index(Router $router) {
        session_start();
        
        // Verificar que el usuario esté autenticado
        if(!isset($_SESSION['login'])) {
            header('Location: /login');
            exit;
        }

        $propiedades = Propiedad::all();
        $vendedores = Vendedor::all();

        // Muestra mensaje condicional
        $resultado = $_GET['resultado'] ?? null;

        $router->render('propiedades/index', [
            'propiedades' => $propiedades,
            'vendedores' => $vendedores,
            'resultado' => $resultado,
            'tipo' => $_SESSION['tipo']
        ]);
    }

    public static function crear(Router $router) {
        session_start();
        
        // Verificar que el usuario esté autenticado y sea administrador o vendedor
        if(!isset($_SESSION['login']) || ($_SESSION['tipo'] !== 'administrador' && $_SESSION['tipo'] !== 'vendedor')) {
            header('Location: /login');
            exit;
        }

        $errores = Propiedad::getErrores();
        $propiedad = new Propiedad;
        $vendedores = Vendedor::all();

        // Ejecutar el código después de que el usuario envía el formulario
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {

            /** Crea una nueva instancia */
            $propiedad = new Propiedad($_POST['propiedad']);

            // Generar un nombre único para la imagen
            $nombreImagen = md5(uniqid(rand(), true)) . ".jpg";

            // Validar
            $errores = $propiedad->validar();

            if (empty($errores)) {

                // Crear la carpeta para subir imágenes si no existe
                if (!is_dir(CARPETA_IMAGENES)) {
                    mkdir(CARPETA_IMAGENES);
                }

                // Guardar la imagen en el servidor
                if ($_FILES['propiedad']['tmp_name']['imagen']) {
                    $image = Image::make($_FILES['propiedad']['tmp_name']['imagen'])->fit(800, 600);
                    $image->save(CARPETA_IMAGENES . $nombreImagen);
                    $propiedad->setImagen($nombreImagen);
                }

                // Guardar en la base de datos
                $resultado = $propiedad->guardar();

                if ($resultado) {
                    header('Location: /propiedades');
                    exit;
                }
            }
        }

        $router->render('propiedades/crear', [
            'errores' => $errores,
            'propiedad' => $propiedad,
            'vendedores' => $vendedores
        ]);
    }

    public static function actualizar(Router $router) {
        session_start();
        
        // Verificar que el usuario esté autenticado y sea administrador o vendedor
        if(!isset($_SESSION['login']) || ($_SESSION['tipo'] !== 'administrador' && $_SESSION['tipo'] !== 'vendedor')) {
            header('Location: /login');
            exit;
        }

        $id = validarORedireccionar('/propiedades');

        // Obtener los datos de la propiedad
        $propiedad = Propiedad::find($id);
        $vendedores = Vendedor::all();
        $errores = Propiedad::getErrores();

        if ($_SERVER['REQUEST_METHOD'] === 'POST') {

            // Asignar los atributos
            $args = $_POST['propiedad'];
            $propiedad->sincronizar($args);

            // Validar
            $errores = $propiedad->validar();

            // Subir archivo si se selecciona una nueva imagen
            if ($_FILES['propiedad']['tmp_name']['imagen']) {
                $nombreImagen = md5(uniqid(rand(), true)) . ".jpg";
                $image = Image::make($_FILES['propiedad']['tmp_name']['imagen'])->fit(800, 600);
                $image->save(CARPETA_IMAGENES . $nombreImagen);
                $propiedad->setImagen($nombreImagen);
            }

            if (empty($errores)) {
                // Guardar en la base de datos
                $resultado = $propiedad->guardar();

                if ($resultado) {
                    header('Location: /propiedades');
                    exit;
                }
            }
        }

        $router->render('propiedades/actualizar', [
            'propiedad' => $propiedad,
            'vendedores' => $vendedores,
            'errores' => $errores
        ]);
    }

    public static function eliminar(Router $router) {
        session_start();
        
        // Verificar que el usuario esté autenticado y sea administrador
        if(!isset($_SESSION['login']) || $_SESSION['tipo'] !== 'administrador') {
            header('Location: /login');
            exit;
        }

        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $id = $_POST['id'];
            $id = filter_var($id, FILTER_VALIDATE_INT);

            if ($id) {
                $propiedad = Propiedad::find($id);
                $resultado = $propiedad->eliminar();

                if ($resultado) {
                    header('Location: /propiedades?resultado=3');
                    exit;
                }
            }
        }
    }
}
